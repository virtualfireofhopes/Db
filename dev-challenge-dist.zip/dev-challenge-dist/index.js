/**
 * This javascript file will constitute the entry point of your solution.
 *
 * Edit it as you need.  It currently contains things that you might find helpful to get started.
 */

// This is not really required, but means that changes to index.html will cause a reload.
// require('./site/index.html')
// Apply the styles in style.css to the page.
// require('./site/style.css')

// if you want to use es6, you can do something like
//     require('./es6/myEs6code')
// here to load the myEs6code.js file, and it will be automatically transpiled.

// Change this to get detailed logging from the stomp library
global.DEBUG = false

class UpdatingTable {
  constructor() {
    const url = "ws://localhost:8011/stomp"
    const client = Stomp.client(url)
    this.data = []
    client.debug = function(msg) {
      if (global.DEBUG) {
        console.info(msg)
      }
    }

    const connectCallback = () => {
      document.getElementById('stomp-status').innerHTML = "It has now successfully connected to a stomp server serving price updates for some foreign exchange currency pairs."
      client.subscribe("/fx/prices", (message) => {this.subscribeCallback(message)})
    }

    client.connect({}, connectCallback, function(error) {
      alert(error.headers.message)
    })
  }

  /**
   * This method is called on receiving new message
   * @param {Object} message - Message from backend
   */
  subscribeCallback(message) {
    let messageObj = JSON.parse(message.body)
    if (message.body && messageObj.name) {
      // Search for existing currency pair
      let updateElem = this.data.findIndex((value) => {
        return value.name == messageObj.name
      })

      // Calculate mid price
      let midPrice = (messageObj.bestBid + messageObj.bestAsk)/2, updateObj

      if (updateElem >= 0) {
        updateObj = this.data[updateElem]
        Object.assign(updateObj, messageObj)
        updateObj.midPriceData.push(midPrice)
        updateObj.midPriceData.length > 30 && updateObj.midPriceData.shift()
        updateObj = messageObj
      } else {
        messageObj.midPriceData = [midPrice]
        this.data.push(messageObj)
      }

      // Sort by last change bid
      this.data.sort((a, b) => b.lastChangeBid - a.lastChangeBid)
      
      this.renderTable()
    } else {
      alert("got empty message")
    }
  }

  /**
   * Render currency table
   */
  renderTable() {
    document.getElementById("container").innerHTML = '';
    this.data.reduce((html, message, index) => html += this.generateTaskHtml(message), '')
  }

  /**
   * Dynamically generate html of updating table
   * @param {Object} message - Details of currency pair
   */
  generateTaskHtml(message) {
    const rowData =document.createElement("tr")
    rowData.innerHTML = `<td>${message.name}</td>
      <td>${message.bestBid}</td>
      <td>${message.bestAsk}</td>
      <td>${message.lastChangeAsk}</td>
      <td>${message.lastChangeBid}</td>
      <td></td>`
    // alert(rowData.lastChild.nodeType)
    Sparkline.draw(rowData.lastChild, message.midPriceData)
    document.getElementById("container").appendChild(rowData)
  }
}

var updatingTable = new UpdatingTable()

module.exports = updatingTable
const { expectation } = require("sinon")
const Sinon = require("sinon")
let clientMock
[window.Stomp, clientMock, window.Sparkline] = require("../mocks/stompMock.js")
const clientSpy = jest.spyOn(clientMock, "connect")

const updatingTable = require("../index.js")

describe("Table tests", ()=>{
    it("should call connect method", ()=>{
        expect(clientMock.connect.mock.calls.length).toBe(1);
    })

    it("should call subscribe method", ()=>{
        let connectCallback = clientMock.connect.mock.calls[0][1]
        let statusElem = document.createElement("div")
        statusElem.id = 'stomp-status'
        document.body.appendChild(statusElem);
        connectCallback();
        expect(clientMock.subscribe.mock.calls.length).toBe(1)
    })

    it("should add new currecy pair on receiving message", ()=>{
        const mssg = {
            body: `{
            "name": "usdjpy",
            "bestBid": 106.7297012204255,
            "bestAsk": 107.25199883791178,
            "openBid": 107.22827132623534,
            "openAsk": 109.78172867376465,
            "lastChangeAsk": -4.862314256927661,
            "lastChangeBid": -2.8769211401569663
          }`
        }

        let subscribeCallback = clientMock.subscribe.mock.calls[0][1]
        let containerElem = document.createElement("table")
        containerElem.id = 'container'
        document.body.appendChild(containerElem);
        subscribeCallback(mssg);
        expect(updatingTable.data.length).toBe(1)
    })
})

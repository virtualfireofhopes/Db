const client = {
    connect: jest.fn(),
    subscribe: jest.fn()
}

function Stomp() {}

Stomp.client = function (url) {
    return client
}

function Sparkline() {}

Sparkline.draw = () => {}

module.exports = [ Stomp, client, Sparkline ]